﻿using AppWeb.Configs;

namespace AppWeb.Models
{
    public class EstoqueDAO
    {
        private readonly Conexao _conexao;
        public EstoqueDAO(Conexao conexao) 
        {
            _conexao = conexao;
        }

        public List<Estoque> ListarTodos() 
        {
            var lista = new List<Estoque>();

            var comando = _conexao.CreateCommand("SELECT * FROM Estoque;");
            var leitor = comando.ExecuteReader();

            while (leitor.Read()) 
            {
                var estoque = new Estoque();
                estoque.Id = leitor.GetInt32("id_est");
                estoque.Nome = DAOHelper.GetString(leitor, "nome_est");
                estoque.Quantidade = leitor.GetInt32("quantidade_est");
                estoque.FormaPagamento = DAOHelper.GetString(leitor, "forma_pagamento_est");
                estoque.Marca = DAOHelper.GetString(leitor, "marca_est");
                estoque.Descricao = DAOHelper.GetString(leitor, "descricao_est");

                estoque.Valor = leitor.GetDecimal("valor_est");

                lista.Add(estoque);
            }

            return lista;
        }

        public void Inserir(Estoque estoque)
        {
            try 
            {
                var comando = _conexao.CreateCommand("INSERT INTO estoque VALUES (null, null, @_nome, @_qtd, @_pagamento, @_marca, @_descricao, @_valor)");

                comando.Parameters.AddWithValue("@_nome", estoque.Nome);
                comando.Parameters.AddWithValue("@_qtd", estoque.Quantidade);
                comando.Parameters.AddWithValue("@_pagamento", estoque.FormaPagamento);
                comando.Parameters.AddWithValue("@_marca", estoque.Marca);
                comando.Parameters.AddWithValue("@_descricao", estoque.Descricao);

                comando.Parameters.AddWithValue("@_valor", estoque.Valor);

                comando.ExecuteNonQuery();
            }

            catch (Exception) 
            {
                throw;    
            }
        }
    }
}


